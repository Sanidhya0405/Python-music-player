# Python Music Player

A simple desktop music player built with **Python**, **Tkinter**, and **Pygame Mixer**. The application provides a graphical interface for loading a songs directory and controlling audio playback.

## Features

- Load songs from a user-selected directory
- Display loaded tracks in a playlist
- Select and play a song
- Pause the current song
- Resume paused playback
- Stop playback
- Display the currently playing song
- Display playback status such as `Song PLAYING`, `Song PAUSED`, `Song RESUMED`, and `Song STOPPED`
- Scroll through the playlist using a vertical scrollbar

## Technologies Used

- **Python**
- **Tkinter** — GUI and directory selection
- **Pygame Mixer** — audio playback
- **OS module** — directory and file handling

## Project Structure

```text
python-music-player/
│
├── musicplayer.py
├── requirements.txt
├── README.md
├── .gitignore
│
└── screenshots/
    ├── music-player-main.png
    ├── music-player-controls.png
    └── music-player-playlist.png
```

## How It Works

### 1. Initialize the Audio Mixer

The application initializes `pygame.mixer` before playback begins.

```python
mixer.init()
```

### 2. Load a Music Directory

The **Load Directory** button opens a directory picker. The selected directory becomes the working directory and its files are loaded into the playlist.

### 3. Play a Song

When a playlist item is selected, the application:

1. Gets the active track from the Listbox.
2. Displays its name in the current-song area.
3. Loads the file through `mixer.music`.
4. Starts playback.
5. Updates the status to `Song PLAYING`.

### 4. Playback Controls

The interface provides:

- **Pause** — pauses playback
- **Stop** — stops playback
- **Play** — plays the selected playlist item
- **Resume** — resumes paused playback

## Installation

Make sure Python is installed, then install the required dependency:

```bash
pip install -r requirements.txt
```

Or:

```bash
pip install pygame
```

## Run the Application

From the project directory:

```bash
python musicplayer.py
```

The application opens a fixed-size GUI titled **PythonGeeks Music Player**.

## Supported Workflow

1. Launch the application.
2. Click **Load Directory**.
3. Select a folder containing your music files.
4. Select a track from the playlist.
5. Click **Play**.
6. Use **Pause**, **Resume**, or **Stop** as required.

## Screenshots

### Main Interface

![Python Music Player](screenshots/music-player-main.png)

### Control Buttons

![Music Player Controls](screenshots/music-player-controls.png)

### Playlist and Current Song

![Music Player Playlist](screenshots/music-player-playlist.png)

## Main Components

The GUI is organized into three main areas:

- **Current Song** — displays the selected/current track
- **Control Buttons** — provides playback controls and directory loading
- **Playlist** — displays the loaded tracks with a scrollbar

## Code Organization

The main functions in `musicplayer.py` are:

| Function | Purpose |
|---|---|
| `play_song()` | Loads and plays the active playlist track |
| `stop_song()` | Stops playback |
| `load()` | Loads files from a selected directory |
| `pause_song()` | Pauses playback |
| `resume_song()` | Resumes paused playback |

## Notes

The current implementation loads all files returned by the selected directory into the playlist. It does not apply an audio-file extension filter, so the selected directory should contain playable audio files supported by the installed Pygame/SDL_mixer environment.

## Learning Outcomes

This project demonstrates practical implementation of:

- GUI development with Tkinter
- Event-driven programming
- File and directory handling
- Audio playback with Pygame
- Tkinter `Listbox`, `Scrollbar`, `Label`, `Button`, and `StringVar`
- Connecting GUI controls to Python functions
